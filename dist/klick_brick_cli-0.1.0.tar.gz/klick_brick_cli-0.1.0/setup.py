# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['klick_brick_cli']

package_data = \
{'': ['*'],
 'klick_brick_cli': ['_trial_temp-1/*', '_trial_temp.lock/*', '_trial_temp/*']}

entry_points = \
{'console_scripts': ['klickbrick = klick_brick_cli:main']}

setup_kwargs = {
    'name': 'klick-brick-cli',
    'version': '0.1.0',
    'description': 'Custom Command Line Interface',
    'long_description': None,
    'author': 'Prudhvi',
    'author_email': 'poornagurram@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
